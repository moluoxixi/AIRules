from pathlib import Path
import hashlib
import json
import os
import signal
import shutil
import subprocess
import time

root = Path(__file__).resolve().parent
project = root / 'project'
source = Path('/Users/mmhm/AIRules/roles/requirement-flow/__test__/scenarios/simple/project')
shutil.copytree(source, project)
git = ['git', '-c', 'core.hooksPath=' + str(root / 'no-hooks'), '-c', 'commit.gpgsign=false']
subprocess.run(git + ['init', '-q'], cwd=project, check=True)
subprocess.run(git + ['add', 'labels.py'], cwd=project, check=True)
subprocess.run(git + ['-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid', 'commit', '-qm', 'Original display label fixture'], cwd=project, check=True)
labels = project / 'labels.py'
original = labels.read_bytes()
assert original.count('以提交'.encode()) == 1
labels.write_bytes(original.replace('以提交'.encode(), '已提交'.encode()))

def snapshot():
    return {str(p.relative_to(project)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(project.rglob('*')) if p.is_file() and '.git' not in p.relative_to(project).parts}

def mode():
    codex_home = Path(os.environ.get('CODEX_HOME', str(Path.home() / '.codex'))).expanduser()
    module = codex_home / 'plugins/cache/ponytail/ponytail/5.3.3/hooks/ponytail-config.js'
    result = subprocess.run(['node', '-e', "const c=require(process.argv[1]); console.log(JSON.stringify({effective:c.getDefaultMode(),config_path:c.getConfigPath()}))", str(module)], check=True, text=True, capture_output=True)
    return json.loads(result.stdout)

before = snapshot()
diff_before = subprocess.check_output(git + ['diff', '--', 'labels.py'], cwd=project)
(root / 'input.diff').write_bytes(diff_before)
mode_before = mode()
prompt = '$ponytail:ponytail-review\n审查当前未提交修改，只报告发现，不修改代码。'
(root / 'prompt.txt').write_text(prompt, encoding='utf-8')
command = ['codex', '--no-daemon', 'exec', '--ephemeral', '--disable', 'apps', '--disable', 'remote_plugin', '--disable', 'recommended_plugins', '-m', 'gpt-6.2-sol', '-c', 'model_reasoning_effort="high"', '-c', 'approval_policy="never"', '-s', 'workspace-write', '--json', '-C', str(project), '-o', str(root / 'final.txt'), '-']
started = time.time()
process = None
timed_out = False
with (root / 'events.jsonl').open('wb') as output, (root / 'stderr.txt').open('wb') as errors:
    try:
        process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=output, stderr=errors, start_new_session=True)
        (root / 'process.json').write_text(json.dumps({'command':command,'pid':process.pid,'started':started,'codex_home':os.environ.get('CODEX_HOME',str(Path.home()/'.codex'))}, ensure_ascii=False, indent=2), encoding='utf-8')
        process.stdin.write(prompt.encode('utf-8'))
        process.stdin.close()
        try:
            process.wait(timeout=300)
        except subprocess.TimeoutExpired:
            timed_out = True
    finally:
        if process is not None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=3)
after = snapshot()
diff_after = subprocess.check_output(git + ['diff', '--', 'labels.py'], cwd=project)
status = subprocess.check_output(git + ['status', '--porcelain'], cwd=project).decode()
report = {'exit_code':process.returncode,'timed_out':timed_out,'seconds':round(time.time()-started,3),
          'before_sha256':before,'after_sha256':after,'content_unchanged':before==after,
          'diff_unchanged':diff_before==diff_after,'git_status':status,
          'default_before':mode_before,'default_after':mode(),
          'baseline_commit':subprocess.check_output(git+['rev-parse','HEAD'],cwd=project).decode().strip()}
(root / 'run-summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))

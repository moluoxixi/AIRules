from pathlib import Path
import hashlib,json,zipfile,shutil
ROOT=Path(__file__).resolve().parent
DEST=Path('/Users/mmhm/AIRules/roles/requirement-flow/verification')
paths=set()
for name in ('native-install','fresh-native','native-hooks','integration/native-review','handoff','browser-project'):
 for path in (ROOT/name).rglob('*'):
  if not path.is_file() or path.is_symlink():continue
  parts=path.relative_to(ROOT).parts
  if any(p in ('.git','__pycache__','node_modules','scratch','tmp','npm-cache') for p in parts):continue
  if path.suffix=='.private':continue
  if 'reader' in parts:continue
  if '.agents' in parts and path.suffix not in ('.md','.py','.yaml'):continue
  paths.add(path)
for path in (ROOT/'checks').iterdir():
 if path.is_file():paths.add(path)
paths.add(ROOT/'OWNED.json')
paths.add(Path(__file__).resolve())
entries=[]
archive=DEST/'ponytail-evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for path in sorted(paths):
  name=path.relative_to(ROOT).as_posix();data=path.read_bytes()
  z.writestr(name,data)
  entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in entries:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
manifest={'archive':'ponytail-evidence.zip','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'entries':entries,'scope':'Actual native hook events, specialist invocation, two fresh-session handoffs, explicit failure/cleanup history, deterministic checks and sample inputs.','excluded':['private config backup and authentication','dependency caches and scratch directories','git metadata and Python bytecode','duplicated reader rendering assets from model skill copies; recover these from the verified role source when needed']}
(DEST/'ponytail-evidence-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archive':str(archive),'bytes':manifest['bytes'],'entries':len(entries),'sha256':manifest['sha256']}))

from datetime import date, timedelta
import sqlite3

def desk_quote(arrival, counter):
    days = 1 if counter == "pop-up" else 3
    return arrival + timedelta(days=days)

def reserve(db, member, counter, arrival):
    deadline = desk_quote(arrival, counter)
    db.execute("insert into holds values (?, ?)", (member, deadline.isoformat()))
    db.commit()

def deadline_for(db, member):
    row = db.execute("select deadline from holds where member = ?", (member,)).fetchone()
    return date.fromisoformat(row[0]) if row else None

def notification_payload(db, member):
    return {"member": member, "collect_by": deadline_for(db, member).isoformat()}

def open_db(path):
    db = sqlite3.connect(path)
    db.execute("create table if not exists holds (member text primary key, deadline text not null)")
    return db

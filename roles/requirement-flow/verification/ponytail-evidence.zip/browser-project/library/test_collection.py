from datetime import date
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from contextlib import closing

from collection import deadline_for, desk_quote, notification_payload, open_db, reserve

class CounterTests(unittest.TestCase):
    def test_popup(self):
        self.assertEqual(desk_quote(date(2026, 2, 28), "pop-up"), date(2026, 3, 1))

    def test_new_and_existing_holds_after_reopening(self):
        arrival = date(2026, 2, 28)
        with TemporaryDirectory(dir=Path(__file__).resolve().parent) as tmp:
            path = Path(tmp) / "holds.sqlite"
            with closing(open_db(path)) as db:
                # A regular hold issued under R12 already carries its deadline.
                db.execute("insert into holds values (?, ?)", ("existing", "2026-03-02"))
                db.commit()
                reserve(db, "new", "regular", arrival)
                reserve(db, "temporary", "pop-up", arrival)

            with closing(open_db(path)) as db:
                for member, counter, expected in (
                    ("new", "regular", date(2026, 3, 3)),
                    ("temporary", "pop-up", date(2026, 3, 1)),
                ):
                    with self.subTest(member=member):
                        self.assertEqual(desk_quote(arrival, counter), expected)
                        self.assertEqual(deadline_for(db, member), expected)
                        self.assertEqual(notification_payload(db, member),
                                         {"member": member, "collect_by": expected.isoformat()})

                self.assertEqual(deadline_for(db, "existing"), date(2026, 3, 2))
                self.assertEqual(notification_payload(db, "existing")["collect_by"], "2026-03-02")

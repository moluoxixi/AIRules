import unittest
import copy
from inventory import Store


class SaveTest(unittest.TestCase):
    def test_save_message(self):
        record = {"id": "a", "shop": "s1", "owner": "u1", "state": "draft",
                  "items": [{"sku": "apple", "quantity": 2}]}
        store = Store({"a": record})
        actor = {"shop": "s1", "id": "u1"}
        record["items"][0]["quantity"] = 3
        self.assertEqual(store.save(record, actor), "保存成功")
        self.assertEqual(store.read("a")["items"][0]["quantity"], 3)
        record["items"][0]["quantity"] = 4
        self.assertEqual(store.read("a")["items"][0]["quantity"], 3)


class CopyCancelledTest(unittest.TestCase):
    def setUp(self):
        self.original = {
            "id": "cancelled-a", "shop": "s1", "owner": "u1",
            "state": "cancelled",
            "items": [{"sku": "apple", "quantity": 2}],
        }
        self.store = Store({"cancelled-a": self.original})
        self.actor = {"shop": "s1", "id": "u1"}

    def test_copy_edit_save_read_and_resubmit(self):
        draft = self.store.copy_cancelled("cancelled-a", self.actor)
        new_id = draft["id"]
        self.assertNotEqual(new_id, "cancelled-a")
        self.assertEqual(draft["state"], "draft")
        self.assertEqual(draft["copied_from"], "cancelled-a")
        self.assertEqual(draft["shop"], "s1")
        self.assertEqual(draft["owner"], "u1")
        self.assertEqual(draft["items"], self.original["items"])
        self.assertEqual(self.store.read(new_id), draft)

        draft["items"][0]["quantity"] = 99
        self.assertEqual(self.store.read(new_id)["items"][0]["quantity"], 2)
        self.store.save(draft, self.actor)
        reopened = self.store.read(new_id)
        self.assertEqual(reopened["items"][0]["quantity"], 99)
        reopened["items"][0]["quantity"] = 1
        self.store.save(reopened, self.actor)
        self.store.submit(new_id, self.actor)
        submitted = self.store.read(new_id)
        self.assertEqual(submitted["state"], "submitted")
        self.assertEqual(submitted["items"][0]["quantity"], 1)
        self.assertEqual(submitted["copied_from"], "cancelled-a")
        self.assertEqual(self.store.read("cancelled-a"), self.original)

        with self.assertRaises(ValueError):
            self.store.submit(new_id, self.actor)
        with self.assertRaises(ValueError):
            self.store.save(submitted, self.actor)
        self.assertEqual(self.store.read(new_id), submitted)

    def test_only_cancelled_can_be_copied(self):
        for state in ("draft", "submitted", "approved"):
            with self.subTest(state=state):
                source = dict(self.original, state=state)
                store = Store({source["id"]: source})
                before = copy.deepcopy(store.records)
                with self.assertRaises(ValueError):
                    store.copy_cancelled(source["id"], self.actor)
                self.assertEqual(store.records, before)

    def test_copy_permissions_and_no_partial_creation(self):
        for actor in ({"shop": "s2", "id": "u1"},
                      {"shop": "s1", "id": "u2"}):
            with self.subTest(actor=actor):
                before = copy.deepcopy(self.store.records)
                with self.assertRaises(PermissionError):
                    self.store.copy_cancelled("cancelled-a", actor)
                self.assertEqual(self.store.records, before)

    def test_repeated_copies_have_independent_identity_and_items(self):
        first = self.store.copy_cancelled("cancelled-a", self.actor)
        second = self.store.copy_cancelled("cancelled-a", self.actor)
        self.assertNotEqual(first["id"], second["id"])
        first["items"][0]["quantity"] = 10
        self.store.save(first, self.actor)
        self.assertEqual(self.store.read(second["id"])["items"][0]["quantity"], 2)
        self.assertEqual(self.store.read("cancelled-a"), self.original)

    def test_invalid_quantity_rejected_then_edit_can_recover(self):
        draft = self.store.copy_cancelled("cancelled-a", self.actor)
        before = self.store.read(draft["id"])
        for invalid in (0, 100, 1.5, True, "2", None):
            with self.subTest(quantity=invalid):
                draft["items"][0]["quantity"] = invalid
                with self.assertRaises(ValueError):
                    self.store.save(draft, self.actor)
                self.assertEqual(self.store.read(draft["id"]), before)
        draft["items"][0]["quantity"] = 3
        self.store.save(draft, self.actor)
        self.store.submit(draft["id"], self.actor)
        self.assertEqual(self.store.read(draft["id"])["items"][0]["quantity"], 3)
        self.assertEqual(self.store.read(draft["id"])["state"], "submitted")

    def test_submit_and_copy_reject_invalid_stored_quantities(self):
        for invalid in (0, 100, 1.5, True, "2", None):
            for state, action in (("draft", "submit"), ("cancelled", "copy_cancelled")):
                with self.subTest(quantity=invalid, action=action):
                    source = copy.deepcopy(self.original)
                    source["state"] = state
                    source["items"][0]["quantity"] = invalid
                    store = Store({source["id"]: source})
                    before = copy.deepcopy(store.records)
                    with self.assertRaises(ValueError):
                        getattr(store, action)(source["id"], self.actor)
                    self.assertEqual(store.records, before)

    def test_save_and_submit_require_stored_owner_and_shop(self):
        draft = self.store.copy_cancelled("cancelled-a", self.actor)
        for actor in ({"shop": "s2", "id": "u1"},
                      {"shop": "s1", "id": "u2"}):
            with self.subTest(actor=actor):
                before = self.store.read(draft["id"])
                forged = copy.deepcopy(draft)
                forged.update(shop=actor["shop"], owner=actor["id"])
                with self.assertRaises(PermissionError):
                    self.store.save(forged, actor)
                with self.assertRaises(PermissionError):
                    self.store.submit(draft["id"], actor)
                self.assertEqual(self.store.read(draft["id"]), before)

    def test_save_cannot_change_ownership_or_copy_provenance(self):
        draft = self.store.copy_cancelled("cancelled-a", self.actor)
        for field, value in (("shop", "s2"), ("owner", "u2"),
                             ("copied_from", "other")):
            with self.subTest(field=field):
                changed = copy.deepcopy(draft)
                changed[field] = value
                with self.assertRaises(ValueError):
                    self.store.save(changed, self.actor)
                self.assertEqual(self.store.read(draft["id"]), draft)

    def test_historical_state_cannot_be_forged_as_draft(self):
        for state in ("cancelled", "submitted", "approved"):
            with self.subTest(state=state):
                source = dict(self.original, state=state)
                store = Store({source["id"]: source})
                forged = dict(source, state="draft")
                with self.assertRaises(ValueError):
                    store.save(forged, self.actor)
                with self.assertRaises(ValueError):
                    store.submit(source["id"], self.actor)
                self.assertEqual(store.read(source["id"]), source)

    def test_unknown_source_does_not_create_record(self):
        before = copy.deepcopy(self.store.records)
        with self.assertRaises(KeyError):
            self.store.copy_cancelled("missing", self.actor)
        self.assertEqual(self.store.records, before)

# 门店库存申请

[业务与权限](spec/current.md) · [正在进行的产品决定](docs/copy-decision.md)

实现为 `inventory.py`，本机运行 `python3 -B -m unittest discover -s tests -v`。

本机已实现复制流程，R13 尚未部署。使用同一 `Store`：

```python
draft = store.copy_cancelled(cancelled_id, actor)
draft["items"][0]["quantity"] = 3
store.save(draft, actor)
reopened = store.read(draft["id"])
store.submit(reopened["id"], actor)
submitted = store.read(reopened["id"])
```

`actor` 为包含 `shop` 和 `id` 的当前操作人；复制、保存、提交均限本店原发起人。数据保存在 Store 实例内存中。验证范围、原保存缺陷、实际结果与后续环境条件见 [D17 交接记录](docs/copy-decision.md#验证与交接)。

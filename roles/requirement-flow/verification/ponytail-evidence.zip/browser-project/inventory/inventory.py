import copy
import uuid


class Store:
    def __init__(self, records):
        self.records = copy.deepcopy(records)

    def read(self, record_id):
        return copy.deepcopy(self.records[record_id])

    @staticmethod
    def _check_actor(record, actor):
        if record["shop"] != actor["shop"] or record["owner"] != actor["id"]:
            raise PermissionError("本店原发起人才可操作")

    @staticmethod
    def _check_quantities(record):
        for item in record["items"]:
            quantity = item["quantity"]
            if type(quantity) is not int or not 1 <= quantity <= 99:
                raise ValueError("数量必须为1到99的整数")

    def copy_cancelled(self, record_id, actor):
        original = self.read(record_id)
        self._check_actor(original, actor)
        if original["state"] != "cancelled":
            raise ValueError("只有已取消申请可复制")
        self._check_quantities(original)
        draft = copy.deepcopy(original)
        new_id = uuid.uuid4().hex
        while new_id in self.records:
            new_id = uuid.uuid4().hex
        draft.update(id=new_id, state="draft", copied_from=record_id)
        self.records[new_id] = copy.deepcopy(draft)
        return draft

    def save(self, record, actor):
        stored = self.read(record["id"])
        self._check_actor(stored, actor)
        if stored["state"] != "draft" or record["state"] != "draft":
            raise ValueError("只有草稿可保存")
        for field in ("shop", "owner", "copied_from"):
            if record.get(field) != stored.get(field):
                raise ValueError("申请归属和复制来源不可修改")
        self._check_quantities(record)
        self.records[record["id"]] = copy.deepcopy(record)
        return "保存成功"

    def submit(self, record_id, actor):
        record = self.read(record_id)
        self.save(record, actor)
        record["state"] = "submitted"
        self.records[record_id] = record

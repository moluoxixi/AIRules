def file_order(owner, depot):
    return {"owner": owner, "depot": depot, "state": "waiting"}

def claim(order, depot):
    if order["state"] != "waiting" or order["depot"] != depot:
        raise ValueError("unavailable")
    order["state"] = "claimed"

def cancel(order, actor):
    if order["owner"] != actor or order["state"] not in ("waiting", "claimed"):
        raise ValueError("unavailable")
    order["state"] = "cancelled"

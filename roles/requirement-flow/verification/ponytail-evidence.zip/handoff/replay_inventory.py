from pathlib import Path
import json
import os
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'frozen/roles/requirement-flow/__test__/scenarios'
TARGET = ROOT / 'scratch/inventory-replay'
assert not TARGET.exists()
TARGET.mkdir()
environment = dict(os.environ, TMPDIR=str(ROOT / 'scratch'), PYTHONDONTWRITEBYTECODE='1', GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_NOSYSTEM='1')

def run(command, cwd):
    result = subprocess.run(command, cwd=cwd, env=environment, text=True, capture_output=True)
    print(json.dumps({'command':list(map(str, command)), 'cwd':str(cwd), 'exit_code':result.returncode, 'stdout':result.stdout, 'stderr':result.stderr}, ensure_ascii=False), flush=True)
    assert result.returncode == 0, result.stdout + result.stderr

try:
    for name in ('simple', 'evolving'):
        shutil.copytree(SOURCE / name / 'project', TARGET / name / 'project')
    run(['git', 'apply', str(SOURCE / 'results/completed.patch')], TARGET)
    run([sys.executable, '-B', '-c', "from labels import label; assert label('draft') == '草稿'; assert label('submitted') == '已提交'; assert label('cancelled') == '已取消'; assert label('missing') == 'missing'; print('all label states retained')"], TARGET / 'simple/project')
    run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-v'], TARGET / 'evolving/project')
    run([sys.executable, '-B', str(ROOT / 'frozen/roles/requirement-flow/skills/requirement-flow/scripts/evidence.py'), 'check', '--project', str(TARGET / 'evolving/project'), 'docs/evidence/copy-cancelled-02.json'], TARGET)
finally:
    assert TARGET.parent == ROOT / 'scratch' and TARGET.name == 'inventory-replay'
    shutil.rmtree(TARGET)
print('completed snapshot replay passed; disposable project cleaned')

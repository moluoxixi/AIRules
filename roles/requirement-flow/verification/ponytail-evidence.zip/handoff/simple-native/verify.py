from pathlib import Path
from datetime import datetime, timezone
import difflib
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / 'project'
INITIAL = ROOT / 'initial-project'
def snapshot(directory):
    items = []
    for path in sorted(directory.rglob('*')):
        if path.is_symlink():
            items.append({'path':str(path.relative_to(directory)), 'kind':'symlink', 'target':str(path.readlink())})
        elif path.is_file():
            data = path.read_bytes()
            items.append({'path':str(path.relative_to(directory)), 'kind':'file', 'size':len(data), 'sha256':hashlib.sha256(data).hexdigest(), 'executable':bool(path.stat().st_mode & 0o111)})
    return items
before = snapshot(INITIAL)
after = snapshot(PROJECT)
(ROOT/'files-after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2)+'\n')
original = (INITIAL/'labels.py').read_text()
current = (PROJECT/'labels.py').read_text()
diff = ''.join(difflib.unified_diff(original.splitlines(keepends=True), current.splitlines(keepends=True), fromfile='initial-project/labels.py', tofile='project/labels.py'))
(ROOT/'actual.diff').write_text(diff)
command = [sys.executable, '-B', '-c', "from labels import label; cases={'draft':'草稿','submitted':'已提交','cancelled':'已取消','not-a-state':'未知状态'}; actual={key:label(key) for key in cases}; assert actual == cases, (actual,cases); print(actual)"]
checked = subprocess.run(command, cwd=PROJECT, text=True, capture_output=True)
added = sorted(set(item['path'] for item in after) - set(item['path'] for item in json.loads((ROOT/'input-before.json').read_text())['project']))
record = {'checked_at':datetime.now(timezone.utc).isoformat(), 'command':command, 'cwd':str(PROJECT), 'exit_code':checked.returncode, 'stdout':checked.stdout, 'stderr':checked.stderr, 'expected_one_line_replacement':current == original.replace('以提交','已提交'), 'new_model_files':added, 'temporary_python_caches':list(map(str, PROJECT.rglob('__pycache__')))}
(ROOT/'verification.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(record, ensure_ascii=False, indent=2))
assert checked.returncode == 0
assert record['expected_one_line_replacement']

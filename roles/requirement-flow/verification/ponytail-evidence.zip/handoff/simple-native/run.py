from pathlib import Path
from datetime import datetime, timezone
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
prompt = '列表里“已提交”显示成了“以提交”，请修正，确认其他状态显示不受影响。'
command = ['codex', '--no-daemon', '-a', 'never', '-s', 'workspace-write', '-m', 'gpt-6.2-sol', '-c', 'model_reasoning_effort="high"', '--disable', 'apps', '--disable', 'remote_plugin', '--disable', 'recommended_plugins', 'exec', '--ephemeral', '--skip-git-repo-check', '--json', '-C', str(ROOT/'project'), '-o', str(ROOT/'final.txt'), prompt]
metadata = {'command':command, 'started_at':datetime.now(timezone.utc).isoformat(), 'fresh_session':True, 'real_user_config':True, 'codex_home_overridden':False}
with (ROOT/'stdout.jsonl').open('w') as stdout, (ROOT/'stderr.txt').open('w') as stderr:
    process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
    metadata['pid'] = process.pid
    (ROOT/'metadata.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+'\n')
    exit_code = process.wait()
metadata.update(exit_code=exit_code, finished_at=datetime.now(timezone.utc).isoformat())
(ROOT/'metadata.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'exit_code':exit_code, 'pid':process.pid}))
raise SystemExit(exit_code)

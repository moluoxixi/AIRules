from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
PROJECT = ROOT / 'model-attempt-02/sandbox/project'
name = sys.argv[1]
prompts = {
  'first': '使用$requirement-flow，让新接手者理解这个项目的图书预约自取业务，核对当前变更、实现和证据，补足本机可做的验证并留下必要接手信息；不部署。',
  'second': '继续这个项目的图书预约自取变更，核对当前业务和已有结果，完成剩余可做事项，交付已验证范围与尚缺条件。',
}
assert name in prompts
command = ['codex', '--no-daemon', '-a', 'never', '-s', 'workspace-write',
           '-m', 'gpt-6.2-sol', '-c', 'model_reasoning_effort="high"',
           '--disable', 'apps', '--disable', 'remote_plugin', '--disable', 'recommended_plugins',
           'exec', '--ephemeral', '--skip-git-repo-check', '--json',
           '-C', str(PROJECT), '-o', str(ROOT / 'audit' / (name + '.final.txt')), prompts[name]]
metadata = {'command':command, 'started_at':datetime.now(timezone.utc).isoformat(),
            'user_config':'real user config, not ignored', 'codex_home_overridden':False,
            'ephemeral':True, 'session_kind':'fresh exec, not resume/fork', 'pid':None}
metadata_path = ROOT / 'audit' / (name + '.metadata.json')
assert not metadata_path.exists()
with (ROOT / 'audit' / (name + '.stdout.jsonl')).open('w') as stdout, (ROOT / 'audit' / (name + '.stderr.txt')).open('w') as stderr:
    process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
    metadata['pid'] = process.pid
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+'\n')
    exit_code = process.wait()
metadata.update(exit_code=exit_code, finished_at=datetime.now(timezone.utc).isoformat())
metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+'\n')
files = []
for path in sorted(PROJECT.rglob('*')):
    if path.is_symlink():
        files.append({'path':str(path.relative_to(PROJECT)), 'kind':'symlink', 'target':str(path.readlink())})
    elif path.is_file():
        data = path.read_bytes()
        files.append({'path':str(path.relative_to(PROJECT)), 'kind':'file', 'size':len(data), 'sha256':hashlib.sha256(data).hexdigest(), 'executable':bool(path.stat().st_mode & 0o111)})
(ROOT / 'audit' / (name + '.files-after.json')).write_text(json.dumps(files, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'session':name, 'exit_code':exit_code, 'files':len(files)}, ensure_ascii=False))
raise SystemExit(exit_code)

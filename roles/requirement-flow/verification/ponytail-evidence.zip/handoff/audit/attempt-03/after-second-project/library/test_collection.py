from datetime import date
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from contextlib import closing

from collection import deadline_for, desk_quote, notification_payload, open_db, reserve

class CounterTests(unittest.TestCase):
    def test_desk_quote(self):
        arrival = date(2026, 2, 28)
        self.assertEqual(desk_quote(arrival, "regular"), date(2026, 3, 3))
        self.assertEqual(desk_quote(arrival, "pop-up"), date(2026, 3, 1))

    def test_new_and_existing_holds_after_reopening(self):
        arrival = date(2026, 2, 28)
        with TemporaryDirectory() as tmp:
            path = Path(tmp) / "holds.sqlite"
            with closing(open_db(path)) as db:
                # A regular hold issued under R12 already carries its deadline.
                db.execute("insert into holds values (?, ?)", ("existing", "2026-03-02"))
                db.commit()
                reserve(db, "new", "regular", arrival)
                reserve(db, "temporary", "pop-up", arrival)

            with closing(open_db(path)) as db:
                for member, expected in (
                    ("new", "2026-03-03"),
                    ("temporary", "2026-03-01"),
                    ("existing", "2026-03-02"),
                ):
                    with self.subTest(member=member):
                        self.assertEqual(deadline_for(db, member), date.fromisoformat(expected))
                        self.assertEqual(notification_payload(db, member),
                                         {"member": member, "collect_by": expected})

from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT = Path.cwd()
PROOF = json.loads((ROOT / 'evidence/library-probe-cleanup.json').read_text())
assert PROOF['status'] == 'deleted'
assert not (ROOT / 'library/2026-03-01').exists()
for name, expected in PROOF['protected_business_inputs_sha256'].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
WORK = ROOT / 'work'
created_work = not WORK.exists()
WORK.mkdir(exist_ok=True)


def run(command, cwd, environment):
    result = subprocess.run(command, cwd=cwd, env=environment, text=True, capture_output=True)
    print(json.dumps({'command': list(map(str, command)), 'cwd': str(cwd),
                      'exit_code': result.returncode, 'stdout': result.stdout,
                      'stderr': result.stderr}, ensure_ascii=False), flush=True)
    assert result.returncode == 0, result.stdout + result.stderr
    return result.stdout + result.stderr


print('Final local verification after independently attributed probe cleanup')
print('Started UTC:', datetime.now(timezone.utc).isoformat())
try:
    with TemporaryDirectory(prefix='library-final-', dir=WORK) as temporary:
        scratch = Path(temporary)
        print('Owned temporary path:', scratch)
        environment = dict(os.environ, TMPDIR=str(scratch), PYTHONDONTWRITEBYTECODE='1')
        result = run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'library', '-v'], ROOT, environment)
        assert 'Ran 2 tests' in result
        database = scratch / 'independent.sqlite'
        writer = """from contextlib import closing
from datetime import date
import sys
from collection import desk_quote, open_db, reserve
arrival = date(2026, 2, 28)
assert desk_quote(arrival, 'regular') == date(2026, 3, 3)
assert desk_quote(arrival, 'pop-up') == date(2026, 3, 1)
with closing(open_db(sys.argv[1])) as db:
    db.execute('insert into holds values (?, ?)', ('existing', '2026-03-02'))
    db.commit()
    reserve(db, 'new', 'regular', arrival)
    reserve(db, 'temporary', 'pop-up', arrival)
print('Writer committed three expected records and exited')
"""
        reader = """from contextlib import closing
from datetime import date
import json
import sys
from collection import deadline_for, notification_payload, open_db
expected = {'new': '2026-03-03', 'temporary': '2026-03-01', 'existing': '2026-03-02'}
with closing(open_db(sys.argv[1])) as db:
    for member, deadline in expected.items():
        assert deadline_for(db, member) == date.fromisoformat(deadline)
        assert notification_payload(db, member) == {'member': member, 'collect_by': deadline}
    assert db.execute('select count(*) from holds').fetchone()[0] == 3
print(json.dumps(expected, sort_keys=True))
"""
        run([sys.executable, '-B', '-c', writer, str(database)], ROOT / 'library', environment)
        run([sys.executable, '-B', '-c', reader, str(database)], ROOT / 'library', environment)
    assert not scratch.exists()
finally:
    if created_work and WORK.exists():
        WORK.rmdir()
assert not (ROOT / 'library/2026-03-01').exists()
assert not list(ROOT.rglob('__pycache__'))
assert not list(ROOT.rglob('*.pyc'))
for name, expected in PROOF['protected_business_inputs_sha256'].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
link_count = 0
for name in ('README.md', 'docs/business/index.md', 'docs/business/library.md',
             'library/README.md', 'library/handbook.md', 'library/docs/changes/regular-holds.md'):
    path = ROOT / name
    for link in re.findall(r'\]\(([^)]+)\)', path.read_text()):
        if '://' not in link:
            assert (path.parent / link.split('#')[0]).exists(), (name, link)
            link_count += 1
print(json.dumps({'local_tests': 2, 'independent_process_readback': 'three records and full notification fields asserted',
                  'stray_database_exists': False, 'business_source_test_rules_unchanged': True,
                  'owned_temporary_workspace_removed': True, 'document_links_resolve': link_count,
                  'remaining_local_authorized_issues': [],
                  'unverified_scope': 'deployment, actual target UI/auth/interfaces, real gateway delivery, other production lifecycle'}, ensure_ascii=False))
print('Finished UTC:', datetime.now(timezone.utc).isoformat())

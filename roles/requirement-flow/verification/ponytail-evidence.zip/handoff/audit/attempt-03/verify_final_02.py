from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

AUDIT = Path(__file__).resolve().parent
PROJECT = AUDIT / 'after-second-project'
INITIAL = AUDIT / 'initial-project'
SCRATCH = AUDIT / 'evaluator-scratch'
assert not SCRATCH.exists()
SCRATCH.mkdir()
env = dict(os.environ, TMPDIR=str(SCRATCH), PYTHONDONTWRITEBYTECODE='1')


def run(command, cwd, expected=0):
    result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, text=True)
    print(json.dumps({'command':list(map(str,command)), 'cwd':str(cwd), 'exit_code':result.returncode, 'stdout':result.stdout, 'stderr':result.stderr},ensure_ascii=False),flush=True)
    assert result.returncode == expected, result.stdout + result.stderr
    return result.stdout + result.stderr


try:
    assert (PROJECT/'library/collection.py').read_bytes() == (INITIAL/'library/collection.py').read_bytes()
    before_skill = {str(p.relative_to(INITIAL/'.agents/skills/requirement-flow')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (INITIAL/'.agents/skills/requirement-flow').rglob('*') if p.is_file()}
    after_skill = {str(p.relative_to(PROJECT/'.agents/skills/requirement-flow')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (PROJECT/'.agents/skills/requirement-flow').rglob('*') if p.is_file()}
    assert before_skill == after_skill
    result = run([sys.executable,'-B','-m','unittest','discover','-s','library','-v'],PROJECT)
    assert 'Ran 2 tests' in result
    db = SCRATCH/'independent.sqlite'
    writer = """from contextlib import closing
from datetime import date
import sys
from collection import desk_quote, open_db, reserve
arrival=date(2026,2,28)
assert desk_quote(arrival,'regular') == date(2026,3,3)
assert desk_quote(arrival,'pop-up') == date(2026,3,1)
with closing(open_db(sys.argv[1])) as connection:
    connection.execute('insert into holds values (?,?)',('existing','2026-03-02'))
    connection.commit()
    reserve(connection,'new','regular',arrival)
    reserve(connection,'temporary','pop-up',arrival)
print('independent writer committed')
"""
    reader = """from contextlib import closing
from datetime import date
import sys
from collection import deadline_for, notification_payload, open_db
expected={'new':'2026-03-03','temporary':'2026-03-01','existing':'2026-03-02'}
with closing(open_db(sys.argv[1])) as connection:
    for member,deadline in expected.items():
        assert deadline_for(connection,member)==date.fromisoformat(deadline)
        assert notification_payload(connection,member)=={'member':member,'collect_by':deadline}
    assert connection.execute('select count(*) from holds').fetchone()[0]==3
print(expected)
"""
    run([sys.executable,'-B','-c',writer,str(db)],PROJECT/'library')
    run([sys.executable,'-B','-c',reader,str(db)],PROJECT/'library')
    source=(PROJECT/'library/collection.py').read_text()
    mutants={
      'popup-two-days':('days = 1 if counter == "pop-up" else 3','days = 2 if counter == "pop-up" else 3'),
      'old-deadline-overwrite':('    db.commit()','    db.execute("update holds set deadline = \'2026-03-03\' where member = \'existing\'")\n    db.commit()'),
      'notification-plus-one-day':('deadline_for(db, member).isoformat()','(deadline_for(db, member) + timedelta(days=1)).isoformat()'),
    }
    for label,(old,new) in mutants.items():
        assert source.count(old)==1,(label,source.count(old))
        work=SCRATCH/label
        work.mkdir()
        (work/'collection.py').write_text(source.replace(old,new))
        shutil.copy2(PROJECT/'library/test_collection.py',work/'test_collection.py')
        failed=run([sys.executable,'-B','-m','unittest','-v'],work,expected=1)
        assert 'AssertionError' in failed and 'FAILED' in failed
        if label=='popup-two-days':
            assert 'FAIL: test_desk_quote' in failed and 'FAIL: test_new_and_existing_holds_after_reopening' in failed
        if label=='old-deadline-overwrite':
            assert "member='existing'" in failed
        if label=='notification-plus-one-day':
            assert 'failures=3' in failed
        (work/'collection.py').write_text(source)
        restored=run([sys.executable,'-B','-m','unittest','-v'],work)
        assert 'Ran 2 tests' in restored
    latest=(PROJECT/'evidence/library-holds-local.output.txt').read_text().split('[续做复验]',1)[1]
    for name,digest in re.findall(r'^SHA-256 (\S+) ([0-9a-f]{64})$',latest,re.M):
        assert hashlib.sha256((PROJECT/name).read_bytes()).hexdigest()==digest,name
    links=0
    for name in ('README.md','docs/business/index.md','docs/business/library.md','library/README.md','library/handbook.md','library/docs/changes/regular-holds.md'):
        path=PROJECT/name
        for link in re.findall(r'\]\(([^)]+)\)',path.read_text()):
            if '://' not in link:
                assert (path.parent/link.split('#')[0]).exists(),(name,link)
                links+=1
    assert not list(PROJECT.rglob('__pycache__')) and not list(PROJECT.rglob('*.pyc'))
    print(json.dumps({'independent_business_assertions':'passed','mutants_detected':list(mutants),'links_resolve':links,'business_source_unchanged':True,'frozen_skill_unchanged':True,'known_first_probe_db_retained':'library/2026-03-01; second honestly documented unconfirmed ownership'},ensure_ascii=False))
finally:
    assert SCRATCH.parent == AUDIT and SCRATCH.name=='evaluator-scratch'
    shutil.rmtree(SCRATCH)
print('Evaluator temporary workspace removed')

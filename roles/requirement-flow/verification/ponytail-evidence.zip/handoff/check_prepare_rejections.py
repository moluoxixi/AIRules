from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SCRIPT = ROOT / 'frozen/roles/requirement-flow/__test__/prepare_reader_example.py'
protected = ROOT / 'frozen'
def digest():
    return [(str(path.relative_to(protected)), hashlib.sha256(path.read_bytes()).hexdigest())
            for path in sorted(protected.rglob('*')) if path.is_file()]
before = digest()
for target, expected in ((protected, 'Output must be a new directory'), (ROOT / 'absent-parent/output', 'Create the output parent directory first')):
    command = [sys.executable, '-B', str(SCRIPT), '--output', str(target)]
    result = subprocess.run(command, capture_output=True, text=True,
                            env=dict(os.environ, TMPDIR=str(ROOT / 'scratch'), PYTHONDONTWRITEBYTECODE='1'))
    print(json.dumps({'command':command, 'exit_code':result.returncode, 'stdout':result.stdout, 'stderr':result.stderr}, ensure_ascii=False))
    assert result.returncode == 1 and expected in result.stderr
assert digest() == before
assert not (ROOT / 'absent-parent').exists()
print('Preparation rejection paths preserve existing files; full preparation waits for final reader docs')

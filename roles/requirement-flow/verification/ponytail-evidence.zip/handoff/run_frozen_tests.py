from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parent
SCRATCH = ROOT / 'scratch'
os.environ['TMPDIR'] = str(SCRATCH)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['GIT_CONFIG_GLOBAL'] = '/dev/null'
os.environ['GIT_CONFIG_NOSYSTEM'] = '1'
tempfile.tempdir = str(SCRATCH)
ORIGINAL_RUN = subprocess.run


def traced_run(*arguments, **options):
    command = list(arguments[0]) if arguments else list(options['args'])
    if Path(str(command[0])).name.startswith('python') and '-B' not in command[1:]:
        command.insert(1, '-B')
    if arguments:
        arguments = (command, *arguments[1:])
    else:
        options['args'] = command
    started = time.time()
    result = ORIGINAL_RUN(*arguments, **options)
    def display(value):
        return value.decode('utf-8', 'replace') if isinstance(value, bytes) else value
    print(json.dumps({'command': command, 'cwd': str(options.get('cwd', Path.cwd())),
                      'exit_code': result.returncode, 'stdout': display(result.stdout),
                      'stderr': display(result.stderr), 'elapsed_seconds': time.time() - started},
                     ensure_ascii=False), flush=True)
    return result


subprocess.run = traced_run
pattern = sys.argv[1]
suite = unittest.defaultTestLoader.discover(str(ROOT / 'frozen/roles/requirement-flow/__test__'), pattern=pattern)
result = unittest.TextTestRunner(verbosity=2).run(suite)
leftovers = sorted(str(path.relative_to(SCRATCH)) for path in SCRATCH.iterdir())
print(json.dumps({'tests_run': result.testsRun, 'failures': len(result.failures),
                  'errors': len(result.errors), 'skipped': len(result.skipped),
                  'scratch_leftovers': leftovers}, ensure_ascii=False), flush=True)
raise SystemExit(0 if result.wasSuccessful() and not leftovers else 1)
